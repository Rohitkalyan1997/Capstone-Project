package com.niit.ArchieveService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArchieveServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
