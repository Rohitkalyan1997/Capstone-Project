package com.niit.taskService.model;

public enum Priority {
    NORMAL,
     HIGH,
    LOW
}
